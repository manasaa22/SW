'use client'
import React from "react";
import { useRouter,useSearchParams } from "next/navigation";
import { useDispatch,useSelector } from "react-redux";
import { useState, useEffect } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
  Button
} from "@mui/material";
import { findRideById, requestRide, searchLocation } from "@/Redux/Ride/Action";
import BookRideNavbar from "./BookRideNavbar";
import AvailableRide from "./AvailableRide";
import SearchResult from "./SearchResult";

const validationSchema = Yup.object().shape({
  pickupLocation: Yup.string().required("Pickup location is required"),
  destinationLocation: Yup.string().required(
    "Destination location is required"
  ),
});
const BookRide = () => {
  const { auth, rides} = useSelector((store) => store);

  const searchParams = useSearchParams();
  const [activeField, setActiveField] = useState(null);
  const router = useRouter();

  const dispatch = useDispatch();
  // Function to get the user's current location and set it as the default pickupLocation
  

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const latitude = position.coords.latitude;
          const longitude = position.coords.longitude;
          const userLocation = `Latitude: ${latitude}, Longitude: ${longitude}`;
          setPickupLocation(userLocation);
        },
        (error) => {
          console.error("Error getting user location:", error);
        }
      );
    } else {
      console.error("Geolocation is not supported in this browser.");
    }
  }, []);

  const handleOnSubmit = (event) => {
    

    console.log("handle on submit ---- ");

    const pickupLatitude = searchParams.get("pickup_lattitude");
    const pickupLongitude = searchParams.get("pickup_longitude");
    const destinationLatitude = searchParams.get("destination_lattitude");
    const destinationLongitude = searchParams.get("destination_longitude");
    const pickupArea = searchParams.get("pickup_area");
    const destinationArea = searchParams.get("destination_area");

    const location = {
      pickupLatitude,
      pickupLongitude,
      destinationLatitude,
      destinationLongitude,
      pickupArea,
      destinationArea,
    };

    dispatch(requestRide({ location, router }));

    console.log("handle submit location - ", location);
  };
  console.log("Rideeeeee",rides)
  useEffect(() => {
    if (rides.rides?.id) {
      const intervalId = setInterval(() => {
       // dispatch(yourActionCreator());

        dispatch(findRideById(ride.ride.id));
      }, 2000);

      return () => {
        clearInterval(intervalId);
      };
    }
  }, [rides]);

  useEffect(() => {
    if (rides.rideDetails?.status == "ACCEPTED") {
      router.push(`/ride-detail/${rides.rideDetails.id}`);
    }
  }, [rides.rideDetails]);

  const onFocused = (e) => {
    setActiveField(e.target.name);
  };

  const formik = useFormik({
    initialValues: {
      pickupLocation:"",
       currentLocation:"", //default
    },
    validationSchema,
    onSubmit: (values) => {
      if (formik.isValid) {
        handleOnSubmit(values);
      }
    },
  });
  
  return (
    <div>
      <BookRideNavbar />
      <div className="flex justify-center items-center  h-screen">
        <div className="px-3 lg:px-5 mt-20 space-y-5">
          <form className="mt-40"
            onSubmit={formik.handleSubmit}
            style={{ backgroundColor: "", height: "40" }}
          >
            <div className="mb-4" style={{ backgroundColor: "#69f0ae" }}>
              <div className="border p-2 flex items-center relative">
                <p className="pr-3">From</p>
                <input
                  name="pickupLocation"
                  placeholder="Enter Pickup Location"
                  value={formik.values.pickupLocation}
                  onChange={(event) => {
                    const value = event.target.value;
                    formik.setFieldValue("pickupLocation", value);
                    dispatch(searchLocation(value));
                  }}
                  onBlur={formik.handleBlur}
                  className="border-none outline-none"
                  onFocus={onFocused}
                />
                {activeField === "pickupLocation" &&
                ride.results?.length > 0 &&
                formik.values.pickupLocation && (
                  <div className="">
                    <SearchResult
                      setActiveField={setActiveField}
                      latitude_key={"pickup_lattitude"}
                      longitude_key={"pickup_longitude"}
                      area_key={"pickup_area"}
                    />
                  </div>
                )}
              </div>
              {formik.touched.pickupLocation &&
                formik.errors.pickupLocation && (
                  <div className="">
                    <p className="text-xs text-red-500 px-2">
                      {formik.errors.pickupLocation}
                    </p>
                  </div>
                )}
            </div>
            <div className="mb-4" style={{ backgroundColor: "#69f0ae" }}>
              <div className="border p-2 flex items-center relative">
                <p className="pr-3">To</p>
                <input
                  name="destinationLocation"
                  placeholder="Enter Destination Location"
                  value={formik.values.destinationLocation}
                  onChange={(event) => {
                    const value = event.target.value;
                    formik.setFieldValue("destinationLocation", value);
                    dispatch(searchLocation(value));
                  }}
                  onBlur={formik.handleBlur}
                  className="border-none outline-none"
                  onFocus={onFocused}
                />
                {activeField === "destinationLocation" && ride.results?.length > 0 &&
                 formik.values?.destinationLocation?.length>0 &&(
                  <div className="">
                    <SearchResult
                      setActiveField={setActiveField}
                      latitude_key={"destination_lattitude"}
                      longitude_key={"destination_longitude"}
                      area_key={"destination_area"}
                    />
                  </div>
                )}
              </div>

              {formik.touched.destinationLocation &&
                formik.errors.destinationLocation && (
                  <div className="">
                    <p className="text-xs text-red-500 px-2">
                      {" "}
                      {formik.errors.destinationLocation}
                    </p>{" "}
                  </div>
                )}
            </div>
            <div mb-4 style={{ backgroundColor: "#8d6e63" }}>
              <Button
                className=""
                sx={{
                  width: "100%",
                  padding: ".7rem 0rem",
                }}
                variant="contained"
                color="secondary"
                type="submit"
              >
                Find Ride
              </Button>
            </div>
            <div className="flex justify-center h-screen mt-45">
         {/*  <p className="flex justify-center mt=45">Available Rides</p><br/> */}
          <div className="space-y-5 mt=50">
              <AvailableRide/>
              <AvailableRide/>
              <AvailableRide/>
          </div>
         </div>
          </form>
        </div>
        <br />
      </div>
      
    </div>
  );
};

export default BookRide;

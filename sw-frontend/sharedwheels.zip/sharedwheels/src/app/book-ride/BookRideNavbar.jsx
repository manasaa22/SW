'use client'
import React from 'react'
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import { drawerList } from "./DrawerList";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import { Avatar,Drawer} from "@mui/material";
import { deepOrange } from "@mui/material/colors";
import { getUser } from '@/Redux/Auth/Action';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
const BookRideNavbar = () => {
    const dispatch=useDispatch();
    const jwt=localStorage.getItem("jwt");
    const {auth}=useSelector(state=>state)
    const [sidebarOpen, setSideBarOpen] = React.useState(false);
    const handleSideBarOpen = () => setSideBarOpen(!sidebarOpen);
    const handleSidebarClose = () => setSideBarOpen(false);
    const router=useRouter()
    useEffect (()=>{
      dispatch(getUser(jwt)) 
   },[])
  return (
    <Box className=''>
      <AppBar sx={{backgroundColor:'black'}} className="" position="static">
        <Toolbar>
          <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="menu"
            sx={{ mr: 2 }}
          >
            <MenuIcon onClick={handleSideBarOpen} />
          </IconButton>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            SharedWheels
          </Typography>

          { auth.user?.fullname ? (
            <Avatar
              className="cursor-pointer"
              
              sx={{ bgcolor: deepOrange[500] }}
              onClick={()=>router.push("/profile")}
            >
            {auth.user?.fullname[0]}
            </Avatar>
          ) : (
            <Button  onClick={()=>router.push("/login")} color="inherit">
              Login
            </Button>
          )}
        </Toolbar>
      </AppBar>
      <Drawer anchor={"left"} open={sidebarOpen} onClose={handleSidebarClose}>
        {drawerList("left")}
      </Drawer> 
    </Box>
  )
}

export default BookRideNavbar
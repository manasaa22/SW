import React from 'react'

const AvailableRide = () => {
  return (
    <div>
      
      <div className='flex-items-center border rounded-md py-2 px-5 courser-pointer -z-10'>
        <img className='w-7' src='x.jpeg' alt=''/>
        <p className='font-semifold text-xs'>1 min</p>
      </div>
      <div className='p1-5 text-sm'>
        <p className='font-semibold'>Prime Ride</p>
        <p className='text-xs -z-10'>
          Available Rides Are Here
        </p>
      </div>
    </div>
  )
}

export default AvailableRide
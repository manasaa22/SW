'use client'
import React from 'react'
import BookRide from './BookRide'
import Layout from '@/components/user/Layout/Layout'
import Footer from '@/components/user/HomePage/Footer'



const page = () => {
  return (
    <div>
      <Layout children={<BookRide/>}></Layout>
      <Footer/>
    </div>
  )
}

export default page
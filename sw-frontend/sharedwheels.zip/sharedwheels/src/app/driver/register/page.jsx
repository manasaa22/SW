import React from 'react'
import Register from '@/app/driver/register/Register'
const page = () => {
  return (
    <div>
       <Register/>
    </div>
  )
}

export default page
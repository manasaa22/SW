import React from 'react'
import RideDetail from './RideDetail'

const page = () => {
  return (
    <div>
      <RideDetail/>
    </div>
  )
}

export default page
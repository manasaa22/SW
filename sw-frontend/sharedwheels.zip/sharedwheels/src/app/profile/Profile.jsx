'use client'
import React, { useEffect } from "react";
import { useRouter } from "next/navigation";
import WestIcon from "@mui/icons-material/West";
import CallIcon from '@mui/icons-material/Call';
import { Avatar, Button } from "@mui/material";
import { yellow } from "@mui/material/colors";
import RideCard from "@/components/user/RideCard/RideCard";
import { useDispatch, useSelector } from "react-redux";
import { getUser, logout } from "@/Redux/Auth/Action";
import Footer from "@/components/user/HomePage/Footer";
const profile = () => {
  const dispatch=useDispatch();
  const jwt=localStorage.getItem('jwt');
  const {auth}=useSelector(state=>state);
  const router = useRouter();
  //console.log(router);
  const goBack = () => {
    router.back();
  };

  useEffect(() => {
    console.log("jwt --- ", jwt);
    if (jwt) {
      dispatch(getUser(jwt));
      dispatch(getCompletedRides());
    }
  }, [jwt]);
  console.log("auth------",auth)
  const handleLogout=()=>{
      dispatch(logout())
      router.push("/book-ride")
  }
  return (
    <div className="px-2 lg:px-5">
      <div className="px-2 lg:px-5 py-2">
        {/* <WestIcon onclick={goBack} className="cursor-pointer" /> */}
      </div>
      <div className="flex flex-col items-center space-y-2">
        <Avatar sx={{ bgcolor: yellow }}>
        {auth.user?.fullname[0]}
        </Avatar>
        <p>{auth.user?.fullname}</p>
        <p>{auth.user?.mobile}</p>
      </div>
      {user.completedRides.length>0 && <div className="border rounded-sm mt-5">
        <RideCard ride={user.completedRides[0]}/>
        {user.completedRides.length>1 && <div className="flex flex-col items-center p-3">
          <Button onClick={() => router.push("/your-rides")} variant="text">
            See all rides
          </Button>
        </div>}
      </div>}

      <div className="border mt-5">
        <div className="flex items-center p-3 border-b">
          <CallIcon />
          <p className="ml-4">Emergency Contact</p>
        </div>
      </div>
      <div className="mt-5">
        <Button
          
          className="w-full bg-red-500 text-white"
          color="error"
          variant="contained"
          onClick={handleLogout}
        >
          Logout
        </Button>
      </div>
      <Footer/>
    </div>
  );
};

export default profile;

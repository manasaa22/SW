'use client'
import React from 'react'
import Profile from './Profile'
const page = () => {
  return (
    <div>
        <Profile/>
    </div>
  )
}

export default page
'use client'
import React from 'react'
import Rides from './Rides'
const page = () => {
  return (
    <Rides/>
  )
}

export default page
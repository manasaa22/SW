'use client'
import React from 'react'
import About from './About'
import HomeP from '@/components/user/HomePage/HomeP'
import Footer from '@/components/user/HomePage/Footer'

const page = () => {
  return (
    <div>
        <HomeP/>
        <About/>
        <Footer/>
    </div>
  )
}

export default page
import React from 'react';
import './About.css'; // Import your CSS file for styling

const About = () => {
  return (
    <div className="about-page">
      <header>
        <h1>About Our SharedWheels Service</h1>
      </header>
      <div className="about-content">
        <p>Welcome to our rideshare service, where convenience and affordability meet to provide you with a seamless transportation experience. Whether you're a passenger looking for a ride or a driver willing to share your journey, we've got you covered.</p>

        <h2>Our Features</h2>
        <div className="feature">
          <img src="/vehicle-icon.jpeg" alt="Car Icon" />
          <h3>Easy Ridesharing</h3>
          <p>Find rides or offer rides effortlessly with our user-friendly platform.</p>
        </div>
        <div className="feature">
          <img src="/map-icon.jpeg" alt="Map Icon" />
          <h3>Convenient Routes</h3>
          <p>Discover rides and drivers heading your way, even within a 5km radius.</p>
        </div>
        <div className="feature">
          <img src="/affortable-icon.jpeg" alt="Affordable Icon" />
          <h3>Affordable Travel</h3>
          <p>Save money on your daily commute by sharing rides with others.</p>
        </div>
      </div>
    </div>
  );
};

export default About;

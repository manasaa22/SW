'use client';
import Image from 'next/image'
import HomeP from '@/components/user/HomePage/HomeP';
import Banner from '@/components/user/HomePage/Banner';
import Footer from '@/components/user/HomePage/Footer';

export default function Home() {
  return (
    <main className="">
      <HomeP/>
      <Banner/>
      <Footer/>
    </main>
  )
}

'use client'
import React, { useState } from 'react';
import './Contact.css'; // Import your CSS file
import { blue } from '@mui/material/colors';

const Contact = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [isMessageSent, setMessageSent] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add your email sending logic here

    // For this example, we'll simulate the message sent
    setMessageSent(true);
  };

  return (
    <div className="contact-container">
      <h2>Contact SharedWheels</h2>
      {isMessageSent ? (
        <p className="success-message">Your message has been sent. We'll get back to you soon!</p>
      ) : (
        <form onSubmit={handleSubmit}>
          <div>
            <label htmlFor="name">Name:</label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div>
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div>
            <label htmlFor="message">Message:</label>
            <textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              required
            />
          </div>
          <button type="submit" style={{backgroundColor:blue}}>Send Message</button>
        </form>
      )}
    </div>
  );
};

export default Contact;

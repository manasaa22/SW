'use client'
import React from 'react'
import Contact from './Contact'
import HomeP from '@/components/user/HomePage/HomeP'
import Footer from '@/components/user/HomePage/Footer'

const page = () => {
  return (
    <div>
        <HomeP/>
        <Contact/>
        <Footer/>
    </div>
  )
}

export default page
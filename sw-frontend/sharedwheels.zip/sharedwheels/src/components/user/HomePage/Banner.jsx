'use clinet'
import React from 'react';
import "./Banner.css";
import CircleIcon from "@mui/icons-material/Circle";
import ArrowRightAltIcon from '@mui/icons-material/ArrowRightAlt';
import { useRouter } from 'next/navigation';
const Banner = () => {
  const router=useRouter();
  return (
    <div className="h-[90vh]">
      <div className="cropped-image"></div>
      <div className="bannerMiniContainer px-36 ">
        <p className=" text-5xl font-bold text-black w-[25rem] mb-5">
          SHARE RIDE,WITHOUT ANY WORRIES
        </p>
        <div className=" bg-white pt-5">
          <div className="flex items-center justify-around">
         
            <div className="flex items-center py-2 px-14 border border-slate-900">
              <CircleIcon className="pr-8 text-green-800 " style={{ fontSize: 40 }} /> <p>Current Location</p>
            </div>
            <div className="flex items-center py-2 px-14 border border-slate-900">
              <CircleIcon className="pr-8 text-red-700 "  style={{ fontSize: 40 }} /> <p>Enter Destination</p>
            </div>
            <div  className="searchRideButton cursor-pointer flex items-center py-4 px-14 border border-slate-900 justify-around">
              <p className="text-white font-semibold" onClick={()=>router.push("/book-ride")}>Search  <span className="text-green-400">Ride</span></p>
              <ArrowRightAltIcon className="text-green-400"/>
            </div>{" "}
            
          </div>

          <div className="mt-10 border position='fixed'">
            <img className="w-full" src="/b11.png" alt="" />
          </div> 
          
          
        </div>
      </div>
    </div>
  )
}

export default Banner
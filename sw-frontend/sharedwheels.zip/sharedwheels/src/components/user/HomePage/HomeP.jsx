import React from 'react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
const HomeP = () => {
  const route=useRouter();
  return (
    <nav className="bg-black py-4">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <div className="flex items-center mx-5">
              <img
                src="/example.png"
                alt="Logo"
                className="w-10 h-10 "
              />
            </div>
            <div>
              <ul className="flex items-center">
                <li className="mr-6">
                  <a href="#" className="text-white hover:text-blue-200" onClick={()=>route.push("/")} >
                    HOME
                  </a>
                </li>
                <li className="mr-6">
                  <a href="#" className="text-white hover:text-blue-200" onClick={()=>route.push("/login")}>
                    LOGIN
                  </a>
                </li>
                <li className="mr-6">
                  <a  className="text-white hover:text-blue-200" onClick={()=>route.push("/register")} >
                    REGISTER
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div>
            <a
              className="bg-white text-black hover:bg-gray-300 text-sm font-semibold px-4 py-3 " onClick={()=>route.push("/about")}
            >
             About
            </a>
            <a className="bg-white text-black hover:bg-gray-300 text-sm font-semibold px-4 py-3 ml-5" onClick={()=>route.push("/contact")}>
              contact
            </a>
           
          </div>
        </div>
      </div>
    </nav>
  )
}

export default HomeP
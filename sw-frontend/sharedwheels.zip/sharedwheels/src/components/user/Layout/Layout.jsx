'use client'
import React from 'react'
import {Grid,TextField,Button} from '@mui/material'
const Layout = ({children}) => {
  return (
    <div className="h-screen border-red-500 border-">
      <Grid container>
        <Grid item xs={12} md={6} lg={7}>
          { children}
        </Grid>
        <Grid item className="h-screen w-full " xs={5} md={6} lg={7}>
          <img
            className="w-full h-full object-cover object-right-top"
            src={
             "/l1.jpg" || "/car.jpg"
            }
          ></img>
        </Grid>
      </Grid>
    </div>
  )
}

export default Layout